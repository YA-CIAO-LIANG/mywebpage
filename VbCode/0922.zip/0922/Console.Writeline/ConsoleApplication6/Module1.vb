﻿Module Module1

    Sub Main()
        Console.WriteLine("====Console.Writeline練習======")

        Console.WriteLine("班級: 資應一甲")
        Console.WriteLine("學號:1110834007 ")

        Console.WriteLine(" 姓名: 梁雅喬")
        Console.WriteLine(" ==============================")
        Console.ReadLine()
    End Sub

End Module
